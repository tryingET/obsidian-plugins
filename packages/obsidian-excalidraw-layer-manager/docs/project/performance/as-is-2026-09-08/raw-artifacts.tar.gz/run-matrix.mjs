import {spawnSync} from 'node:child_process';
import {appendFileSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const dir=fileURLToPath(new URL('.',import.meta.url));
const passes=process.argv[2]?.split(',')??['baseline-1'];
for(const pass of passes)for(const n of [1000,10000,50000,100000])for(const shape of ['ungrouped','small10','many2','giant','nested8','skew90']){
 const label=`${pass}-${shape}-${n}`;
 const start=Date.now();
 const result=spawnSync(process.execPath,['--max-old-space-size=768',`${dir}matrix.mjs`,shape,String(n),pass],{encoding:'utf8',timeout:120000,maxBuffer:8*1024*1024});
 writeFileSync(`${dir}${label}.jsonl`,result.stdout??'');writeFileSync(`${dir}${label}.err`,result.stderr??'');
 const row={label,pass,n,shape,status:result.status,signal:result.signal,error:result.error?.message,elapsedMs:Date.now()-start,command:[process.execPath,'--max-old-space-size=768',`${dir}matrix.mjs`,shape,String(n),pass]};
 appendFileSync(`${dir}runs.jsonl`,JSON.stringify(row)+'\n'); console.log(JSON.stringify(row));
}
