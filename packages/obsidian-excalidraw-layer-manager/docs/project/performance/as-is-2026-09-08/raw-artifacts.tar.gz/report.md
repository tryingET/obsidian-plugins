# Scout: LayerManager as-is exploratory performance

## Verdict

Measured substantial large-scene CPU work before any DOM/Obsidian render. At100k rectangles, median of three independent baseline process medians: full tree ~97–267ms; unchanged runtime refresh with no DOM ~121–315ms; rename one via fake updateScene+refresh ~176–393ms. Many tiny groups and depth8 hierarchy are materially more expensive than one giant group. This is a candidate hotspot map, not host-latency ground truth, an accepted evaluator, or an optimization win.

## Revision / PR

- Baseline HEAD `66bbe11f8d7e9a2e589dcbb350d9bac5507a22db`.
- `git diff ebc1099 HEAD -- packages/obsidian-excalidraw-layer-manager/src` empty. Current source matches documented outgoing source `ebc1099`.
- Live read-only `gh pr view 2925 --repo zsviczian/obsidian-excalidraw-plugin ...`: OPEN, head `2d14cb90c5e69f3490f59c4b450e3a762f85d786`, exactly LayerManager.md/svg.
- Downloaded exact PR commit's Markdown via GitHub contents API: SHA256 `8039c3abbaf22cd25e7720f8d2970bd626df8584fffe089d59bb177fa60b8889`, matches receipt. Existing local dist hash `9032818dda258072ff77a20f380cdade62866996e9bee90e1ee410ae988f42b1` matches receipt's pre-terminal-newline-normalization build. No fresh native deploy or source build-to-PR equivalence assertion beyond these observations.
- Initial git status only preexisting untracked `.ontology/`; final additionally parent-owned docs/project/performance/. Scout made no shared-cwd edits.

## Measurement

Node26.8.1, V8 14.6, Linux7.1.11-arch1-1, AMD Threadripper PRO7975WX32-core/64threads, esbuild0.28.2, Vitest4.1.11. Boost enabled, no affinity/governor pin. Initial load6.39/6.24/6.20. Each scenario fresh sequential process, --max-old-space-size=768; two warmups and five measured repetitions for each operation. Assertions excluded from timing but affect GC/cache state between iterations. Max observed sampled RSS861.9MiB/heap630.0MiB, not peak/leak measurements.

24 shape-size cells:1k/10k/50k/100k × ungrouped / contiguous groups10 / contiguous groups2 / one giant / depth8 broad hierarchy (leaf groups10, doubles per level) / 90% giant plus10%pairs. All rectangles, no host.

Three independent baseline passes and three same-bundle no-change passes:144 processes,260 operation cells,1560 timing rows,7800 measured samples, all child exits0 and row statusok. ~605s total child elapsed. No candidate changes. Per-process p95=max for five samples; pooled30-sample tails descriptive only. Per-pass medians retained; noise ratio nochange/baseline across cells min0.404,median0.999,max2.196;16 cells>1.2 and11<0.8. Do not infer sub-percent changes or universal tolerance from these mixed scales.

Operations: index construction; full tree collapsed/expanded; visible-row projection collapsed/expanded and match-all filter; visibility planner; first-outer-group rename planner; front reorder planner; unchanged runtime refresh; runtime single-element rename using real production fallback updateScene with in-memory array replacement and model-only renderer. Planners aren't end-to-end operations. Rename runtime proves target label change and untouched elements, not native staging.

### Median of three baseline process medians, ms

|Shape|Elements|Tree collapsed|Runtime refresh, no DOM|Rename one+refresh, no DOM|
|---|---:|---:|---:|---:|
|ungrouped|1000|1.02|0.67|1.47|
|ungrouped|10000|11.04|8.87|11.51|
|ungrouped|50000|47.58|54.23|82.89|
|ungrouped|100000|97.49|136.71|176.30|
|small10|100000|134.13|170.78|217.42|
|many2|100000|224.27|290.11|378.01|
|giant|100000|97.84|120.85|187.05|
|nested8|100000|267.16|314.64|393.13|
|skew90|100000|100.24|138.55|196.57|

Do not subtract separately sampled phases as a precise cost decomposition. All24 cells and260 operation statistics are in cell-summary.jsonl, including min/median/max across process medians, pooled samples and per-pass values.

## Existing benchmarks observed

Four files/eight tests passed in serial Node run. Timings saved in existing-benchmarks-verbose.log (first run's default reporter suppressed console): tree2k p50/p95=1.62/3.42ms; reparent2k move500=3.71/5.81ms; reorder=1.59/2.49ms; runtime checksum-render=4.38/7.98ms. Complexity500→2000 p50 ratios:tree3.65,reorder3.32,reparent4.16. Tree prebuilds indexes outside timer; runtime render is checksum walk, not DOM. EA mocks have no-op staging/addElements; statusapplied alone is not native mutation evidence.

## Hot path map (inspection, not profile attribution)

- `src/adapter/excalidrawAdapter.ts:152` readSnapshot normalizes every raw element.
- `src/main.ts:renderSnapshot` builds element-ID set, indexes, full tree, visual-state map; controller.setTree rebuilds full node index. Expansion triggers refresh, not just a visible-row projection.
- `src/domain/treeBuilder.ts:464` sorts ordered input, builds maps/sets/group nodes. Group finalization copies descendant membership at each nesting level; group-label lookup scans candidate members. Hidden/collapsed branches still retain complete structural ownership by design. Removing that structure to appear faster would be a semantic regression.
- `src/runtime/runtimeLifecycleMachine.ts:94` command planning re-reads snapshot/indexes; reorder planner builds full tree; application refresh rebuilds it again.
- `src/ui/excalidrawSidepanelRenderer.ts:beginLiveRender` clears contentRoot.innerHTML and rebuilds chrome/rows each live render; prepareLiveRenderState performs selection/filter/destination/visible-context projections. No DOM virtualization/paint measurement here. Full reconstruction is a strong host experiment target, not a measured fraction of latency.
- `src/ui/sidepanel/render/rowModel.ts` counts all searchable structural nodes even when collapsed; match-all filter recreates projected rows. `rowTreeRenderer.ts` recursively visits expanded visible rows.

## Correctness and falsifiers

Existing and scratch tests are exploratory weak proxies. See audit-findings.md and summary.json limitations before reuse. Particularly: self-derived group hierarchy oracle; count-only filter checks; reorder permutation not exact ordering; group-rename payload not checked; visibility restoration absent; unchanged-refresh stale cache can pass; untouched-target fields absent. These admit doing less useful work. No proof of production bugs implied.

Concrete next experiment: under owner-authorized frozen evaluator task, independently specify small nested/frame/bound-text/deleted fixtures with exact structural ownership/order/filter outputs and changed-scene refresh holdouts; then measure one100k-many2 baseline in an owned disposable Obsidian host with rendered row count, requestAnimationFrame/long-task timing, memory snapshots and interaction correctness. Compare collapsed versus expanded separately without discarding hidden ownership. Preserve rename draft/focus, pending mutation authority, native staging isolation, view replacement, selection and undo/save/reopen holdouts from current tests. Restrict UI mutation/deployment to disposable owner-authorized host, never personal vault.

Expected impact: identify whether measured Node structural work or host DOM reconstruction dominates user-perceived stalls, and reject invalid cached/pruned fast paths before optimization. No quantified win proposed.

## Reproduction / artifacts

Commands, repo/commit/tool versions, hashes, counters and key-cell statistics: summary.json. Exact source-entry bundle imports: entry.ts; subject.mjs frozen bundle; matrix.mjs fixture+measure+checks; run-matrix.mjs process runner. Per-process exact command/status in runs.jsonl. Fixture serialization SHA256 values: fixture-identities.json (generated using exact generator prefix after timing). Tracked source/dependency-lock file hashes: source-hashes.json. All raw pass/scenario JSONL/error files retained; no overwrite after finished passes. Before re-running, create a NEW owned TMPDIR directory/run identity, rebuild subject under explicitly selected source revision, and repair/freeze oracles and runner exit behavior first.

## Risks / rollback / don't repeat

No source optimization, deploy, AK mutation, git commit or service restart by scout; rollback unnecessary. Scratch immutable artifacts may be removed only after owner retention and verified inactivity. Do not repeat2k-only applied/nonempty checks as proof of huge-host responsiveness; don't optimize away collapsed ownership, preflight/staging or rename/lifecycle work to satisfy weak oracles; don't use these exploratory timings for autonomous acceptance. Controller reported autonomy runner fail-closed blocker separately; this report does not clear it.
