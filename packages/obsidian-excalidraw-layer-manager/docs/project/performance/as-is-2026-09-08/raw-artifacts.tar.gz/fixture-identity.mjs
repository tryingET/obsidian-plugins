import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import * as s from './subject.mjs';
const [shape='ungrouped', sizeArg='1000', pass='baseline-1'] = process.argv.slice(2);
const n=Number(sizeArg), warmup=2, repeats=5;
function groupIds(i) {
  if(shape==='ungrouped') return [];
  if(shape==='small10') return [`g-${Math.floor(i/10)}`];
  if(shape==='many2') return [`g-${Math.floor(i/2)}`];
  if(shape==='giant') return ['giant'];
  if(shape==='nested8') return Array.from({length:8},(_,d)=>`d${d}-${Math.floor(i/(10*2**d))}`);
  if(shape==='skew90') return i < n*.9 ? ['giant'] : [`g-${Math.floor(i/2)}`];
  throw new Error(shape);
}
const elements=Array.from({length:n},(_,i)=>s.makeElement({id:`e-${i}`,zIndex:i,groupIds:groupIds(i)}));
console.log(JSON.stringify({shape,n,serialization:'JSON.stringify(elements), UTF-8',sha256:createHash('sha256').update(JSON.stringify(elements)).digest('hex'),elements:elements.length,groupMemberships:elements.reduce((a,e)=>a+e.groupIds.length,0)}));
