import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import * as s from './subject.mjs';
const [shape='ungrouped', sizeArg='1000', pass='baseline-1'] = process.argv.slice(2);
const n=Number(sizeArg), warmup=2, repeats=5;
function groupIds(i) {
  if(shape==='ungrouped') return [];
  if(shape==='small10') return [`g-${Math.floor(i/10)}`];
  if(shape==='many2') return [`g-${Math.floor(i/2)}`];
  if(shape==='giant') return ['giant'];
  if(shape==='nested8') return Array.from({length:8},(_,d)=>`d${d}-${Math.floor(i/(10*2**d))}`);
  if(shape==='skew90') return i < n*.9 ? ['giant'] : [`g-${Math.floor(i/2)}`];
  throw new Error(shape);
}
const elements=Array.from({length:n},(_,i)=>s.makeElement({id:`e-${i}`,zIndex:i,groupIds:groupIds(i)}));
const snapshot=s.makeSnapshot(elements), indexes=s.buildSceneIndexes(snapshot), context={snapshot,indexes};
let tree=s.buildLayerTree({elements,expandedNodeIds:new Set(),groupFreedraw:true},indexes);
function validateTree(t){
 const ids=new Set(), nodes=new Set(); let groups=0, memberships=0;
 function visit(ns){for(const node of ns){assert(!nodes.has(node.id),'duplicate node'); nodes.add(node.id); memberships+=node.elementIds.length;
  if(node.type==='element'){assert.equal(node.elementIds.length,1); assert(!ids.has(node.primaryElementId));ids.add(node.primaryElementId);}
  if(node.type==='group'){groups++;const want=new Set((indexes.elementsByGroupId.get(node.groupId)||[]).map(e=>e.id));assert.equal(node.elementIds.length,want.size); for(const id of node.elementIds)assert(want.has(id));}
  visit(node.children);
 }} visit(t);assert.equal(ids.size,n);return {nodes:nodes.size,groups,memberships,expandedNodeIds:nodes};
}
const expected=validateTree(tree), expandedTree=s.buildLayerTree({elements,expandedNodeIds:expected.expandedNodeIds,groupFreedraw:true},indexes);
const headIds=elements.slice(0,Math.min(500,Math.floor(n/10))).map(e=>e.id);
const group=elements[0].groupIds.at(-1);
let latestModel, renders=0, scene=elements.map(e=>({...e,groupIds:[...e.groupIds],customData:{...e.customData}}));
const api={updateScene:({elements:next})=>{scene=next}};
const ea={getViewElements:()=>scene,getViewSelectedElements:()=>[],getScriptSettings:()=>({}),getExcalidrawAPI:()=>api};
const runtime=s.createLayerManagerRuntime(ea,{render:m=>{latestModel=m;renders++;}});
function pct(a,p){return [...a].sort((a,b)=>a-b)[Math.ceil(a.length*p)-1]}
async function bench(operation,fn,check){
 const timings=[]; let result;
 for(let i=0;i<warmup+repeats;i++){
  const start=performance.now(); result=await fn(i); const duration=performance.now()-start;
  check(result,i); // checks deliberately OUTSIDE timer
  if(i>=warmup)timings.push(duration);
  if(duration>3000) {console.log(JSON.stringify({pass,shape,n,operation,status:'guarded_slow',duration,warmup,repeats,measured:timings}));return;}
 }
 console.log(JSON.stringify({pass,shape,n,operation,status:'ok',warmup,repeats,timings,p50:pct(timings,.5),p95:pct(timings,.95),max:Math.max(...timings),rss:process.memoryUsage().rss,heapUsed:process.memoryUsage().heapUsed,nodes:expected.nodes,groups:expected.groups,memberships:expected.memberships}));
}
try {
 await bench('indexes',()=>s.buildSceneIndexes(snapshot),v=>{assert.equal(v.byId.size,n);assert.equal(v.elementsByGroupId.size,indexes.elementsByGroupId.size)});
 await bench('tree-collapsed',()=>s.buildLayerTree({elements,expandedNodeIds:new Set(),groupFreedraw:true},indexes),v=>{assert.deepEqual(validateTree(v),expected)});
 await bench('tree-expanded',()=>s.buildLayerTree({elements,expandedNodeIds:expected.expandedNodeIds,groupFreedraw:true},indexes),v=>{assert.deepEqual(validateTree(v),expected)});
 await bench('filter-collapsed-empty',()=>s.buildSidepanelVisibleRowTreeResult(tree,''),v=>{assert.equal(v.searchableRowCount,expected.nodes);assert.equal(v.renderedRowCount,tree.length)});
 await bench('filter-expanded-empty',()=>s.buildSidepanelVisibleRowTreeResult(expandedTree,''),v=>{assert.equal(v.renderedRowCount,expected.nodes)});
 await bench('filter-collapsed-match-all',()=>s.buildSidepanelVisibleRowTreeResult(tree,'rectangle'),v=>{assert.equal(v.matchingRowCount,n);assert.equal(v.renderedRowCount,expected.nodes)});
 await bench('plan-visibility-500',()=>s.planToggleVisibility(context,{elementIds:headIds}),v=>{assert(v.ok);assert.deepEqual(v.value.elementPatches.map(p=>p.id),headIds);for(const p of v.value.elementPatches)assert.equal(p.set.opacity,0)});
 if(group) await bench('plan-group-rename',()=>s.planRenameNode(context,{groupId:group,nextName:'bench'}),v=>{assert(v.ok);assert.deepEqual(v.value.elementPatches.map(p=>p.id),indexes.elementsByGroupId.get(group).map(e=>e.id))});
 await bench('plan-reorder-front',()=>s.planReorder(context,{orderedElementIds:headIds,mode:'front'}),v=>{assert(v.ok);assert(v.value.reorder,'must do real reorder');const order=v.value.reorder.orderedElementIds;assert.equal(order.length,n);assert.equal(new Set(order).size,n);assert.notDeepEqual(order,elements.map(e=>e.id));for(const id of order)assert(indexes.byId.has(id))});
 await bench('runtime-refresh-no-DOM',()=>{const before=renders;runtime.refresh();return before},before=>{assert(renders>before);assert.equal(runtime.getSnapshot().elements.length,n);assert.equal(validateTree(latestModel.tree).nodes,expected.nodes)});
 let renameSequence=0;
 await bench('runtime-rename-one-updateScene-no-DOM',async()=>{const nextName=`bench-${++renameSequence}`;const outcome=await runtime.commands.renameNode({elementId:`e-${n-1}`,nextName});return {outcome,nextName}},({outcome,nextName})=>{assert.equal(outcome.status,'applied');assert.equal(latestModel.tree.length,tree.length);const leaves=[];const walk=ns=>{for(const node of ns){if(node.primaryElementId===`e-${n-1}`&&node.type==='element')leaves.push(node);walk(node.children)}};walk(latestModel.tree);assert.equal(leaves.length,1);assert.equal(leaves[0].label,nextName);for(let i=0;i<n-1;i++)assert.deepEqual(scene[i],elements[i]);});
} finally {runtime.dispose()}
