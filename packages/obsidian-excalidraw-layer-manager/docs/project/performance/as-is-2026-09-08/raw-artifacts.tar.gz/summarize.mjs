import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {cpus,release,platform,arch} from 'node:os';
const dir=fileURLToPath(new URL('.',import.meta.url)),repo='/home/tryinget/ai-society/softwareco/owned/obsidian-plugins',pkg=repo+'/packages/obsidian-excalidraw-layer-manager';
const read=f=>readFileSync(dir+f,'utf8'), hash=x=>createHash('sha256').update(x).digest('hex');
const files=readdirSync(dir).filter(f=>/^(baseline|nochange)-\d-.+\.jsonl$/.test(f)).sort();
const rows=files.flatMap(f=>read(f).trim().split('\n').filter(Boolean).map(line=>({...JSON.parse(line),artifact:f})));
const runs=read('runs.jsonl').trim().split('\n').map(JSON.parse);
const med=a=>{const s=[...a].sort((a,b)=>a-b);return s.length%2?s[(s.length-1)/2]:(s[s.length/2-1]+s[s.length/2])/2};
const pct=(a,p)=>[...a].sort((a,b)=>a-b)[Math.ceil(a.length*p)-1];
const dist=a=>({min:Math.min(...a),median:med(a),max:Math.max(...a)});
const keys=[...new Set(rows.map(r=>`${r.n}/${r.shape}/${r.operation}`))].sort();
const cells=keys.map(key=>{
 const subset=rows.filter(r=>`${r.n}/${r.shape}/${r.operation}`===key),first=subset[0],timings=subset.flatMap(r=>r.timings??[]);
 const b=subset.filter(r=>r.pass.startsWith('baseline')),c=subset.filter(r=>r.pass.startsWith('nochange'));
 return {n:first.n,shape:first.shape,operation:first.operation,requestedTargetCount:first.operation==='plan-visibility-500'||first.operation==='plan-reorder-front'?Math.min(500,Math.floor(first.n/10)):first.operation==='plan-group-rename'?first.shape==='giant'?first.n:first.shape==='skew90'?first.n*.9:first.shape==='small10'?10:first.shape==='many2'?2:Math.min(first.n,1280):first.operation.startsWith('runtime-rename')?1:null,nodes:first.nodes,groups:first.groups,memberships:first.memberships,processMedianMs:dist(subset.map(r=>r.p50)),baselineMedianMs:dist(b.map(r=>r.p50)),nochangeMedianMs:dist(c.map(r=>r.p50)),nochangeOverBaselineMedian:med(c.map(r=>r.p50))/med(b.map(r=>r.p50)),samples:timings.length,pooledSampleMedianMs:med(timings),pooledDescriptiveP95Ms:pct(timings,.95),perPass:subset.map(r=>({pass:r.pass,p50:r.p50,p95:r.p95,max:r.max,artifact:r.artifact}))};
});
writeFileSync(dir+'cell-summary.jsonl',cells.map(v=>JSON.stringify(v)).join('\n')+'\n');
// Fixture identity executes only the exact already-used generator prefix. No measurements.
const generator=read('matrix.mjs').split('const snapshot=s.makeSnapshot(elements)')[0];
writeFileSync(dir+'fixture-identity.mjs',`import {createHash} from 'node:crypto';\n`+generator+`console.log(JSON.stringify({shape,n,serialization:'JSON.stringify(elements), UTF-8',sha256:createHash('sha256').update(JSON.stringify(elements)).digest('hex'),elements:elements.length,groupMemberships:elements.reduce((a,e)=>a+e.groupIds.length,0)}));\n`);
const fixtures=[];
for(const n of [1000,10000,50000,100000])for(const shape of ['ungrouped','small10','many2','giant','nested8','skew90'])fixtures.push(JSON.parse(execFileSync(process.execPath,[dir+'fixture-identity.mjs',shape,String(n)],{encoding:'utf8'})));
writeFileSync(dir+'fixture-identities.json',JSON.stringify(fixtures,null,2)+'\n');
const sourcePaths=execFileSync('git',['ls-files','packages/obsidian-excalidraw-layer-manager/src','packages/obsidian-excalidraw-layer-manager/test/testFixtures.ts','packages/obsidian-excalidraw-layer-manager/package.json','package-lock.json'],{cwd:repo,encoding:'utf8'}).trim().split('\n');
const sourceHashes=sourcePaths.map(path=>({path,sha256:hash(readFileSync(repo+'/'+path))}));
writeFileSync(dir+'source-hashes.json',JSON.stringify(sourceHashes,null,2)+'\n');
const watched=['entry.ts','matrix.mjs','run-matrix.mjs','subject.mjs','vitest.config.mjs','fixture-identities.json','source-hashes.json','summarize.mjs'];
const limits=[
 'Exploratory Node synthetic measurement, not frozen campaign evaluator. No production optimizations, no candidate wins, no real-vault deploy or Obsidian DOM/layout/paint/native EA staging.',
 'All rectangles, contiguous groups, uniform z-order, empty metadata, no frames/bound text/images/freedraw/deletion. nested8 is breadth-containing depth8, not extreme nesting. Fixed shape/operation order; GC state and checks influence following iterations.',
 'Two warmups/five samples per operation/process: per-process p95 equals max; pooled 30-sample p95 descriptive only, not responsiveness/tail confidence. Async bench await adds microtask overhead to sync functions.',
 'Memory samples are cumulative process RSS/heap after operations and correctness checks; not isolated allocations, peak, leaks or heap-safety proof. Processes capped at 768MiB old-space; no multi-GiB run.',
 'Tree leaf uniqueness/coverage checked; group oracle uses subject indexes and expected node/group counts from initial subject tree. Missing hierarchy/incorrect parent paths or duplicate group membership can escape.',
 'Filter checks counters, not exact visibleTree/matchKindByNodeId. Reorder checks changed full permutation only, not exact desired order/structural semantics; planners do not apply mutations.',
 'Group rename planner checks target IDs not set payload; visibility only target IDs+opacity, not originalOpacity restoration. Runtime rename checks target leaf label and all OTHER element contents, not target preservation.',
 'Runtime refresh unchanged scene: freshness/invalidation not exercised. Runtime uses actual fake updateScene array replacement, no provided DOM renderer; no copyViewElementsToEAforEditing/addElementsToView native path.',
 'plan-visibility-500 and reorder target min(500,floor(n/10)):100 at1k,500 larger. Rename first outer group:2/many2,10/small10,n/giant,.9n/skew90,min(n,1280)/nested8.',
 'Runner exits zero even if a child fails; independently audited runs.jsonl all144 status0, no signals, all1560 rows statusok. Reusing same pass names overwrites artifacts; do not reuse immutable run labels.',
 'Baseline vs nochange labels are unchanged frozen bundle across chronological fresh processes, not branch-reset/alternating pairs; noise/drift estimates not campaign acceptance thresholds.'
];
const summary={kind:'exploratory-as-is-baseline',capturedAt:new Date().toISOString(),source:{repo,head:'66bbe11f8d7e9a2e589dcbb350d9bac5507a22db',sourceCommit:'ebc1099',sourceDiff:'git diff ebc1099 HEAD -- packages/obsidian-excalidraw-layer-manager/src: empty',sourceHashesArtifact:'source-hashes.json',pr:JSON.parse(read('pr2925.json')),prPayloadSha256:hash(readFileSync(dir+'pr2925-LayerManager.md')),prMatch:'Exact live PR head and fetched payload match publication receipt; source same as ebc1099; no fresh deploy/build of published artifact performed.'},environment:{node:process.version,versions:process.versions,platform:platform(),arch:arch(),kernel:release(),cpu:cpus()[0].model,logicalCpus:cpus().length,esbuild:JSON.parse(readFileSync(repo+'/node_modules/esbuild/package.json','utf8')).version,vitest:'4.1.11',heapOldSpaceMiB:768,initialLoadAverage:'6.39 6.24 6.20',artifact:'environment.txt',afterArtifact:'environment-after.txt'},counts:{passes:6,baselinePasses:3,nochangePasses:3,shapeSizeCells:24,operationCells:cells.length,scenarioProcesses:runs.length,operationRows:rows.length,measuredSamples:rows.reduce((a,r)=>a+(r.timings?.length??0),0),warmupsPerOperation:2,measuredRepeatsPerOperation:5,scenarioElapsedMs:runs.reduce((a,r)=>a+r.elapsedMs,0)},failures:{children:runs.filter(r=>r.status!==0||r.signal),operations:rows.filter(r=>r.status!=='ok')},commands:{bundle:'node_modules/.bin/esbuild "$D/entry.ts" --bundle --platform=node --format=esm --outfile="$D/subject.mjs"',first:'node "$D/run-matrix.mjs" baseline-1',additional:'node "$D/run-matrix.mjs" baseline-2,baseline-3,nochange-1,nochange-2,nochange-3',existing:'cd packages/obsidian-excalidraw-layer-manager && node_modules/.bin/vitest run --config "$D/vitest.config.mjs" --configLoader native --no-cache --no-file-parallelism --maxWorkers 1 --silent=false --reporter verbose --disableConsoleIntercept test/treeBuilder.performance.test.ts test/commands.performance.test.ts test/runtime.render-update.performance.test.ts test/performance.complexity-sentinel.test.ts',summary:'node "$D/summarize.mjs"',D:dir},hashes:watched.map(path=>({path,sha256:hash(readFileSync(dir+path))})),fixturesArtifact:'fixture-identities.json',allOperationCellStatisticsArtifact:'cell-summary.jsonl',keyOperationStatistics:cells.filter(c=>['tree-collapsed','runtime-refresh-no-DOM','runtime-rename-one-updateScene-no-DOM'].includes(c.operation)).map(({perPass,...v})=>v),noise:{nochangeOverBaselineMedianAcrossOperationCells:dist(cells.map(c=>c.nochangeOverBaselineMedian)),cellsAbove120pct:cells.filter(c=>c.nochangeOverBaselineMedian>1.2).length,cellsBelow80pct:cells.filter(c=>c.nochangeOverBaselineMedian<.8).length,warning:'Counts mix workloads; not an acceptance metric. Per-pass medians retained in cell-summary.jsonl.'},limitations:limits};
writeFileSync(dir+'summary.json',JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({counts:summary.counts,failures:summary.failures,noise:summary.noise},null,2));
