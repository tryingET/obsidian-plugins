# Independent scratch harness audit

Read-only reviewer ASC `dispatch-1788864675157` inspected entry.ts, matrix.mjs, run-matrix.mjs and targeted subject source. No changes or tests by reviewer. These are oracle limitations, not observed production bugs.

- Expected tree group/node counts come from subject-produced initial tree. Flattening all groups could pass; exact parent paths aren't checked. Group membership loop checks length+inclusion, not uniqueness/set equality.
- Filter checks counters, not visibleTree/matchKindByNodeId; empty or wrong projection could pass with expected counters.
- Group rename planner checks IDs, not patch set fields. Visibility ignores saved opacity restoration metadata. Runtime rename checks target label and every other element but not preservation of target's own unrelated fields.
- Unchanged-scene refresh never falsifies stale caching: must change source content/group ownership in a holdout to verify invalidation.
- Driver logs child errors but doesn't propagate aggregate error exit; same label overwrites artifacts. Runs manifest has been independently read: all 144 recorded children status0/no signal.
- plan-visibility-500/reorder request100 IDs at1k,500 otherwise. First outer group rename targets2/many2,10/small10,n/giant,.9n/skew90,min(n,1280)/nested8.

Minimal proposed holdouts: independently specified nested tree including exact ordering/expanded flags and shuffled input; selective and miss filter exact rows/context/matchKind; target metadata preservation and opacity hide/restore; changed-scene refresh; intentionally failing child must fail aggregate runner with unique artifacts. Do not optimize against these exploratory checks as though they were a frozen evaluator.
